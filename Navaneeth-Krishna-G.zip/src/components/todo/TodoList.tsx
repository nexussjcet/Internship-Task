import { TodoItem } from './TodoItem';
import { TodoForm } from './TodoForm';
import { TodoFilters } from './TodoFilters';
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useTodos } from '@/hooks/useTodos';
import { Todo } from '@/lib/types';
import { AlertCircle, Plus } from 'lucide-react';

export function TodoList() {
  const {
    todos,
    addTodo,
    toggleTodo,
    deleteTodo,
    clearCompleted,
    filter,
    setFilter,
    activeCount,
    completedCount,
    isLoading,
    error,
  } = useTodos();

  const handleAddTodo = (text: string) => {
    try {
      addTodo(text);
    } catch (error) {
      console.error('Failed to add todo:', error);
    }
  };

  const [isProcessing, setIsProcessing] = useState(false);

  const handleToggleTodo = async (id: string) => {
    if (isProcessing) return;
    try {
      setIsProcessing(true);
      await toggleTodo(id);
    } catch (error) {
      console.error('Failed to toggle todo:', error);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDeleteTodo = async (id: string) => {
    if (isProcessing) return;
    try {
      setIsProcessing(true);
      await deleteTodo(id);
    } catch (error) {
      console.error('Failed to delete todo:', error);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleClearCompleted = async () => {
    if (isProcessing) return;
    try {
      setIsProcessing(true);
      await clearCompleted();
    } catch (error) {
      console.error('Failed to clear completed todos:', error);
    } finally {
      setIsProcessing(false);
    }
  };

  if (isLoading) {
    return (
      <div className="w-full max-w-3xl mx-auto mt-16 px-6 flex flex-col items-center justify-center py-16">
        <div className="animate-pulse flex flex-col items-center">
          <div className="h-10 w-10 rounded-full bg-sky-300 mb-4"></div>
          <div className="h-5 w-52 bg-sky-200 rounded"></div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="w-full max-w-3xl mx-auto mt-16 px-6">
        <div className="bg-red-100 border border-red-400 text-red-800 px-4 py-3 rounded-lg flex items-start gap-3">
          <AlertCircle className="h-5 w-5 mt-0.5 flex-shrink-0" />
          <div>
            <h2 className="font-semibold">Oops! Something went wrong</h2>
            <p className="text-sm">{error.message || 'Could not load tasks. Try again later.'}</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full max-w-3xl mx-auto mt-16 px-6">
      <h1 className="text-5xl font-extrabold text-center mb-10 text-red-600 drop-shadow-md">My Todos</h1>

      <div className="bg-white rounded-3xl shadow-2xl border border-gray-200 overflow-hidden mb-10">
        <div className="p-6 border-b border-gray-100 flex items-center gap-4">
          <div className="flex-1">
            <TodoForm onSubmit={handleAddTodo} />
          </div>
        </div>

        {todos.length > 0 ? (
          <>
            <motion.ul 
              className="divide-y divide-gray-100"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.4 }}
            >
              <AnimatePresence>
                {todos.map((todo: Todo) => (
                  <motion.li 
                    key={todo.id}
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    transition={{ duration: 0.25 }}
                    layout
                  >
                    <TodoItem
                      todo={todo}
                      onToggle={handleToggleTodo}
                      onDelete={handleDeleteTodo}
                    />
                  </motion.li>
                ))}
              </AnimatePresence>
            </motion.ul>

            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.15 }}
            >
              <TodoFilters
                filter={filter}
                setFilter={setFilter}
                activeCount={activeCount}
                hasCompleted={completedCount > 0}
                onClearCompleted={handleClearCompleted}
                isLoading={isProcessing}
              />
            </motion.div>
          </>
        ) : (
          <motion.div 
            className="py-20 text-center"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
          >
            <div className="mx-auto w-24 h-24 bg-indigo-100 rounded-full flex items-center justify-center mb-6">
              <Plus className="w-10 h-10 text-indigo-400" />
            </div>
            <h3 className="text-2xl font-semibold text-gray-700 mb-2">You're all set!</h3>
            <p className="text-gray-500 mb-6">
              {filter === 'all' 
                ? 'No tasks yet. Create your first task now!' 
                : filter === 'active' 
                  ? 'All tasks completed. Time to chill!' 
                  : 'No tasks have been completed yet.'}
            </p>
            <div className="flex justify-center gap-4">
              {filter !== 'all' && (
                <button
                  onClick={() => setFilter('all')}
                  className="inline-flex items-center justify-center rounded-full border border-indigo-300 text-indigo-600 px-5 py-2.5 text-sm font-medium hover:bg-indigo-100 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                >
                  View All
                </button>
              )}
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}