import React from 'react';
import './style.css';

function App() {
  return (
    <div className="App">
      {/* Hero Section */}
      <section className="hero">
        <h1>HackSphere 2025</h1>
        <p>“Code. Create. Conquer.”</p>
        <p>June 20–22, 2025 – Online</p>
        <button className="cta">Register Now</button>
      </section>

      {/* About Section */}
      <section className="about">
        <h2>About the Event</h2>
        <p>
          HackSphere 2025 is a 48-hour global online hackathon bringing together
          developers, designers, and creators from around the world.
          Collaborate, learn, and innovate to build amazing projects.
        </p>
        <p>
          Whether you're a beginner or experienced hacker, this is your space to
          shine, network, and win!
        </p>
      </section>

      {/* Footer */}
      <footer>
        <p>© 2025 HackSphere. All rights reserved.</p>
      </footer>
    </div>
  );
}

export default App;
