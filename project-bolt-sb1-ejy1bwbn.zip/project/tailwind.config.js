/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        'sans': ['Inter', 'ui-sans-serif', 'system-ui', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'Roboto', 'Helvetica Neue', 'Arial', 'sans-serif'],
      },
      colors: {
        primary: {
          50: '#fff1f1',
          100: '#ffe1e1',
          200: '#ffc7c7',
          300: '#ffa0a0',
          400: '#ff6b6b',
          500: '#ff3838',
          600: '#ff1111',
          700: '#db0000',
          800: '#b50000',
          900: '#960000',
        },
        accent: {
          50: '#fff9eb',
          100: '#ffefc7',
          200: '#ffdf89',
          300: '#ffcf5b',
          400: '#ffb41c',
          500: '#ffa200',
          600: '#e68a00',
          700: '#cc7700',
          800: '#a65f00',
          900: '#804800',
        },
      },
      animation: {
        'float': 'float 6s ease-in-out infinite',
      },
    },
  },
  plugins: [],
};