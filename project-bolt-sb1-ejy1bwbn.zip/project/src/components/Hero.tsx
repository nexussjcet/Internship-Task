import React from 'react';
import { ArrowRight, Code, Globe, Users } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-br from-primary-900 via-primary-800 to-primary-900">
      {/* Background Image */}
      <div 
        className="absolute inset-0 z-0 opacity-20 bg-cover bg-center"
        style={{
          backgroundImage: "url('https://images.pexels.com/photos/1181671/pexels-photo-1181671.jpeg?auto=compress&cs=tinysrgb&w=1920')"
        }}
      ></div>
      
      {/* Overlay gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-primary-900/50 to-primary-900/90"></div>
      
      {/* Content */}
      <div className="container mx-auto px-6 py-16 relative z-10 text-center">
        <div className="inline-block mb-4 px-4 py-1 rounded-full bg-accent-500/10 backdrop-blur-sm border border-accent-500/20">
          <p className="text-accent-300 font-medium tracking-wide text-sm md:text-base">
            JUNE 20–22, 2025 – ONLINE
          </p>
        </div>
        
        <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold text-white mb-6 tracking-tight">
          Hack<span className="text-accent-400">Sphere</span> 2025
        </h1>
        
        <p className="text-xl md:text-2xl lg:text-3xl text-white/90 font-light mb-10">
          Code. Create. Conquer.
        </p>
        
        <div className="flex flex-col sm:flex-row items-center justify-center gap-6 mb-16">
          <button className="group px-8 py-4 bg-gradient-to-r from-accent-500 to-accent-600 hover:from-accent-600 hover:to-accent-700 text-primary-900 font-bold rounded-lg text-lg transition-all duration-300 flex items-center gap-2 shadow-lg shadow-accent-500/30">
            Register Now
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </button>
          <a href="#about" className="px-8 py-4 bg-primary-800/50 hover:bg-primary-800/70 backdrop-blur-sm text-white font-medium rounded-lg text-lg transition-all duration-300 border border-accent-500/20">
            Learn More
          </a>
        </div>

        <div className="flex flex-wrap justify-center gap-8 text-white/80">
          <div className="flex items-center gap-2">
            <Globe className="w-5 h-5 text-accent-400" />
            <span>100+ Countries</span>
          </div>
          <div className="flex items-center gap-2">
            <Users className="w-5 h-5 text-accent-400" />
            <span>10,000+ Participants</span>
          </div>
          <div className="flex items-center gap-2">
            <Code className="w-5 h-5 text-accent-400" />
            <span>$50K in Prizes</span>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;