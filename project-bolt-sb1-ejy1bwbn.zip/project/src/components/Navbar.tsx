import React, { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';

const Navbar: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const scrollPosition = window.scrollY;
      setIsScrolled(scrollPosition > 50);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      isScrolled ? 'bg-primary-900/95 shadow-md backdrop-blur-sm py-4' : 'bg-transparent py-6'
    }`}>
      <div className="container mx-auto px-6">
        <div className="flex justify-between items-center">
          <a href="#" className="text-2xl font-bold text-white">
            Hack<span className="text-accent-400">Sphere</span>
          </a>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <a href="#" className="text-white hover:text-accent-300 transition-colors duration-300">Home</a>
            <a href="#about" className="text-white hover:text-accent-300 transition-colors duration-300">About</a>
            <a href="#schedule" className="text-white hover:text-accent-300 transition-colors duration-300">Schedule</a>
            <a href="#faq" className="text-white hover:text-accent-300 transition-colors duration-300">FAQ</a>
            <a href="#partners" className="text-white hover:text-accent-300 transition-colors duration-300">Partners</a>
            <a href="#contact" className="text-white hover:text-accent-300 transition-colors duration-300">Contact</a>
            <a 
              href="#" 
              className="px-5 py-2.5 bg-gradient-to-r from-accent-500 to-accent-600 hover:from-accent-600 hover:to-accent-700 text-primary-900 font-bold rounded-lg transition-all duration-300"
            >
              Register
            </a>
          </nav>

          {/* Mobile Menu Button */}
          <button 
            className="md:hidden text-white focus:outline-none"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Navigation */}
      <div className={`md:hidden overflow-hidden transition-all duration-300 ${
        isMenuOpen ? 'max-h-96 border-b border-accent-500/20' : 'max-h-0'
      }`}>
        <nav className="container mx-auto px-6 py-4 flex flex-col space-y-4 bg-primary-900/95 backdrop-blur-sm">
          <a 
            href="#" 
            className="text-white hover:text-accent-300 transition-colors duration-300 py-2"
            onClick={() => setIsMenuOpen(false)}
          >
            Home
          </a>
          <a 
            href="#about" 
            className="text-white hover:text-accent-300 transition-colors duration-300 py-2"
            onClick={() => setIsMenuOpen(false)}
          >
            About
          </a>
          <a 
            href="#schedule" 
            className="text-white hover:text-accent-300 transition-colors duration-300 py-2"
            onClick={() => setIsMenuOpen(false)}
          >
            Schedule
          </a>
          <a 
            href="#faq" 
            className="text-white hover:text-accent-300 transition-colors duration-300 py-2"
            onClick={() => setIsMenuOpen(false)}
          >
            FAQ
          </a>
          <a 
            href="#partners" 
            className="text-white hover:text-accent-300 transition-colors duration-300 py-2"
            onClick={() => setIsMenuOpen(false)}
          >
            Partners
          </a>
          <a 
            href="#contact" 
            className="text-white hover:text-accent-300 transition-colors duration-300 py-2"
            onClick={() => setIsMenuOpen(false)}
          >
            Contact
          </a>
          <a 
            href="#" 
            className="px-5 py-2.5 bg-gradient-to-r from-accent-500 to-accent-600 hover:from-accent-600 hover:to-accent-700 text-primary-900 font-bold rounded-lg transition-all duration-300 inline-block text-center"
            onClick={() => setIsMenuOpen(false)}
          >
            Register
          </a>
        </nav>
      </div>
    </header>
  );
};

export default Navbar;