import React, { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';

const FAQ: React.FC = () => {
  const faqs = [
    {
      question: "Who can participate in HackSphere 2025?",
      answer: "HackSphere is open to everyone from students to professionals, regardless of experience level. Whether you're a coding expert or just starting your tech journey, you're welcome to join!"
    },
    {
      question: "Do I need to have a team to register?",
      answer: "No, you can register as an individual and form a team later. We'll have team formation activities at the beginning of the event to help you find teammates with complementary skills."
    },
    {
      question: "What kind of projects can I build?",
      answer: "You can build any software project that addresses the hackathon themes, which will be announced closer to the event. Projects typically span web/mobile apps, AI/ML solutions, blockchain applications, IoT systems, and more."
    },
    {
      question: "Is HackSphere 2025 completely virtual?",
      answer: "Yes, HackSphere 2025 is a fully virtual event. All activities including coding sessions, workshops, mentoring, and judging will take place online through our dedicated event platform."
    },
    {
      question: "Is there an entry fee?",
      answer: "No, participation in HackSphere 2025 is completely free of charge, thanks to our generous sponsors."
    },
    {
      question: "What are the judging criteria?",
      answer: "Projects will be judged based on innovation, technical complexity, practical implementation, user experience, and relevance to the hackathon themes. Specific judging criteria will be shared prior to the event."
    },
    {
      question: "Will there be mentors available during the hackathon?",
      answer: "Absolutely! We'll have experienced mentors from leading tech companies available throughout the event to provide guidance, answer questions, and help you overcome technical challenges."
    },
    {
      question: "What technologies can I use?",
      answer: "You're free to use any programming languages, frameworks, APIs, or tools of your choice. We encourage creativity in your technical approach!"
    }
  ];

  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  const toggleFaq = (index: number) => {
    setActiveIndex(activeIndex === index ? null : index);
  };

  return (
    <section id="faq" className="py-20 bg-gray-50">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Frequently Asked Questions</h2>
          <div className="w-20 h-1 bg-gradient-to-r from-cyan-500 to-blue-500 mx-auto mb-8"></div>
          <p className="text-lg md:text-xl text-gray-700 max-w-3xl mx-auto">
            Everything you need to know about HackSphere 2025
          </p>
        </div>

        <div className="max-w-3xl mx-auto">
          {faqs.map((faq, index) => (
            <div 
              key={index} 
              className="mb-4 border border-gray-200 rounded-lg overflow-hidden bg-white"
            >
              <button
                className="w-full p-6 text-left bg-white hover:bg-gray-50 flex justify-between items-center transition-colors duration-300"
                onClick={() => toggleFaq(index)}
              >
                <span className="text-lg font-medium text-gray-900">{faq.question}</span>
                {activeIndex === index ? 
                  <ChevronUp className="w-5 h-5 text-gray-600" /> : 
                  <ChevronDown className="w-5 h-5 text-gray-600" />
                }
              </button>
              
              <div 
                className={`px-6 overflow-hidden transition-all duration-300 ease-in-out ${
                  activeIndex === index ? 'max-h-96 pb-6' : 'max-h-0'
                }`}
              >
                <p className="text-gray-700 leading-relaxed">{faq.answer}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FAQ;