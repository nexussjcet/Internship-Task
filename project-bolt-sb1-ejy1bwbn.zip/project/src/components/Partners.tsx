import React from 'react';

const Partners: React.FC = () => {
  // In a real application, these would be actual partner logos
  // For this example, we're using colored rectangles as placeholders
  const partners = [
    { name: "TechGiant", color: "bg-blue-500" },
    { name: "InnovateCorp", color: "bg-purple-500" },
    { name: "Future Systems", color: "bg-cyan-500" },
    { name: "DevWorld", color: "bg-indigo-500" },
    { name: "CodeCraft", color: "bg-pink-500" },
    { name: "ByteWorks", color: "bg-violet-500" },
    { name: "CloudNet", color: "bg-teal-500" },
    { name: "DataSphere", color: "bg-emerald-500" },
  ];

  const tiers = [
    { name: "Platinum Sponsors", partners: partners.slice(0, 2) },
    { name: "Gold Sponsors", partners: partners.slice(2, 5) },
    { name: "Silver Sponsors", partners: partners.slice(5) }
  ];

  return (
    <section id="partners" className="py-20 bg-white">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Our Partners</h2>
          <div className="w-20 h-1 bg-gradient-to-r from-cyan-500 to-blue-500 mx-auto mb-8"></div>
          <p className="text-lg md:text-xl text-gray-700 max-w-3xl mx-auto">
            HackSphere is made possible thanks to these amazing organizations
          </p>
        </div>

        <div className="space-y-16">
          {tiers.map((tier, tierIndex) => (
            <div key={tierIndex}>
              <h3 className="text-2xl font-semibold text-center mb-8 text-gray-800">{tier.name}</h3>
              <div className={`grid grid-cols-1 ${tier.name === "Platinum Sponsors" ? 'sm:grid-cols-2' : 'sm:grid-cols-2 md:grid-cols-3'} gap-8`}>
                {tier.partners.map((partner, partnerIndex) => (
                  <div 
                    key={partnerIndex} 
                    className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300 p-6 flex flex-col items-center"
                  >
                    <div className={`w-full h-24 ${partner.color} rounded-lg flex items-center justify-center mb-4`}>
                      <span className="text-white font-bold text-xl">{partner.name}</span>
                    </div>
                    <p className="text-gray-600 text-center">Empowering innovation through technology</p>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 text-center">
          <p className="text-lg text-gray-700 mb-6">Interested in sponsoring HackSphere 2025?</p>
          <a 
            href="#contact" 
            className="inline-block px-6 py-3 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white font-medium rounded-lg transition-all duration-300 shadow-md hover:shadow-lg"
          >
            Become a Sponsor
          </a>
        </div>
      </div>
    </section>
  );
};

export default Partners;