import React, { useState } from 'react';
import { Send } from 'lucide-react';

const Contact: React.FC = () => {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real application, you would send this to your backend
    // For this demo, we'll just show a success message
    if (email) {
      setSubscribed(true);
      setEmail('');
    }
  };

  return (
    <section id="contact" className="py-20 bg-gradient-to-br from-indigo-900 via-purple-900 to-violet-900 text-white">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Stay Updated</h2>
          <div className="w-20 h-1 bg-gradient-to-r from-cyan-400 to-blue-400 mx-auto mb-8"></div>
          <p className="text-lg md:text-xl text-white/80 max-w-3xl mx-auto">
            Subscribe to our newsletter for exclusive updates, announcements, and tips
          </p>
        </div>

        <div className="max-w-2xl mx-auto bg-white/10 backdrop-blur-md rounded-2xl p-8 md:p-10 border border-white/20">
          {!subscribed ? (
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-white/90 mb-2">
                  Email Address
                </label>
                <input
                  type="email"
                  id="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  required
                  className="w-full px-4 py-3 bg-white/5 border border-white/20 rounded-lg focus:ring-2 focus:ring-cyan-400 focus:border-transparent placeholder-white/40 text-white"
                />
              </div>
              
              <button 
                type="submit"
                className="w-full px-6 py-3 bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 text-white font-medium rounded-lg transition-all duration-300 flex items-center justify-center gap-2"
              >
                Subscribe to Updates
                <Send className="w-5 h-5" />
              </button>
              
              <p className="text-sm text-white/60 text-center">
                We respect your privacy. Unsubscribe at any time.
              </p>
            </form>
          ) : (
            <div className="text-center py-8">
              <div className="w-16 h-16 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-full flex items-center justify-center mx-auto mb-6">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <h3 className="text-2xl font-bold mb-2">Thanks for subscribing!</h3>
              <p className="text-white/80">
                You're now on our list and will be the first to hear about HackSphere updates.
              </p>
            </div>
          )}
        </div>

        <div className="mt-16 text-center">
          <p className="text-lg mb-4">Have questions? Get in touch with us:</p>
          <a 
            href="mailto:info@hacksphere2025.com" 
            className="text-cyan-300 hover:text-cyan-200 transition-colors duration-300 font-medium"
          >
            info@hacksphere2025.com
          </a>
        </div>
      </div>
    </section>
  );
};

export default Contact;