import React from 'react';
import { Calendar, Clock } from 'lucide-react';

const Schedule: React.FC = () => {
  const scheduleItems = [
    {
      day: "Day 1 - Friday, June 20",
      events: [
        { time: "09:00 AM - 10:00 AM", title: "Opening Ceremony", description: "Welcome address and event kickoff" },
        { time: "10:00 AM - 11:00 AM", title: "Team Formation", description: "Find teammates and discuss project ideas" },
        { time: "11:00 AM - 12:00 PM", title: "Workshop: AI Fundamentals", description: "Introduction to practical AI implementation" },
        { time: "12:00 PM - 01:00 PM", title: "Lunch Break", description: "Virtual networking sessions" },
        { time: "01:00 PM - 03:00 PM", title: "Hacking Begins", description: "Start building your projects" },
        { time: "07:00 PM - 08:00 PM", title: "Evening Check-in", description: "Progress updates and mentor matching" }
      ]
    },
    {
      day: "Day 2 - Saturday, June 21",
      events: [
        { time: "09:00 AM - 10:00 AM", title: "Morning Check-in", description: "Progress updates and announcements" },
        { time: "10:00 AM - 11:00 AM", title: "Workshop: Pitching Your Project", description: "Learn how to present your idea effectively" },
        { time: "11:00 AM - 12:00 PM", title: "Technical Office Hours", description: "Get help from industry experts" },
        { time: "03:00 PM - 04:00 PM", title: "Mid-Hackathon Challenge", description: "Quick competition with bonus prizes" },
        { time: "07:00 PM - 08:00 PM", title: "Virtual Game Night", description: "Take a break and have some fun" }
      ]
    },
    {
      day: "Day 3 - Sunday, June 22",
      events: [
        { time: "09:00 AM - 10:00 AM", title: "Final Check-in", description: "Last-minute announcements and guidance" },
        { time: "12:00 PM", title: "Submission Deadline", description: "All projects must be submitted" },
        { time: "01:00 PM - 03:00 PM", title: "Project Presentations", description: "Teams present their solutions to judges" },
        { time: "04:00 PM - 05:00 PM", title: "Judging Deliberation", description: "Judges evaluate all submissions" },
        { time: "05:00 PM - 06:00 PM", title: "Closing Ceremony", description: "Winners announced and final remarks" }
      ]
    }
  ];

  return (
    <section id="schedule" className="py-20 bg-gradient-to-b from-primary-950 to-primary-900">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Event Schedule</h2>
          <div className="w-20 h-1 bg-gradient-to-r from-accent-400 to-accent-500 mx-auto mb-8"></div>
          <p className="text-lg md:text-xl text-primary-200 max-w-3xl mx-auto">
            Mark your calendar for three days of innovation, learning, and fun
          </p>
        </div>

        <div className="max-w-5xl mx-auto">
          {scheduleItems.map((day, dayIndex) => (
            <div key={dayIndex} className="mb-12 last:mb-0">
              <div className="flex items-center gap-3 mb-6">
                <Calendar className="w-6 h-6 text-accent-400" />
                <h3 className="text-2xl font-bold text-white">{day.day}</h3>
              </div>
              
              <div className="border-l-4 border-accent-500 pl-8 space-y-8">
                {day.events.map((event, eventIndex) => (
                  <div 
                    key={eventIndex} 
                    className="relative bg-primary-800/30 backdrop-blur-sm p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300 border border-accent-500/20"
                  >
                    <div className="absolute w-4 h-4 bg-accent-500 rounded-full -left-10 top-8 border-4 border-primary-900"></div>
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                      <div>
                        <h4 className="text-xl font-semibold text-white">{event.title}</h4>
                        <p className="text-primary-200 mt-1">{event.description}</p>
                      </div>
                      <div className="flex items-center gap-2 text-accent-400 font-medium bg-accent-400/10 px-4 py-2 rounded-full whitespace-nowrap">
                        <Clock className="w-4 h-4" />
                        <span>{event.time}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Schedule;