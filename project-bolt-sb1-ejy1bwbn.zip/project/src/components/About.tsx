import React from 'react';
import { Award, Clock, Cloud, Code, Coffee, Cpu, Globe, Users } from 'lucide-react';

const About: React.FC = () => {
  return (
    <section id="about" className="py-20 bg-gradient-to-b from-primary-900 to-primary-950">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">About HackSphere</h2>
          <div className="w-20 h-1 bg-gradient-to-r from-accent-400 to-accent-500 mx-auto mb-8"></div>
          <p className="text-lg md:text-xl text-primary-200 max-w-3xl mx-auto">
            Redefining the boundaries of innovation through global collaboration
          </p>
        </div>
        
        <div className="max-w-4xl mx-auto bg-primary-800/30 backdrop-blur-sm rounded-2xl shadow-xl overflow-hidden mb-16 border border-accent-500/20">
          <div 
            className="h-64 bg-cover bg-center"
            style={{
              backgroundImage: "url('https://images.pexels.com/photos/3182812/pexels-photo-3182812.jpeg?auto=compress&cs=tinysrgb&w=1920')"
            }}
          ></div>
          <div className="p-8 md:p-12">
            <p className="text-primary-200 mb-6 leading-relaxed">
              HackSphere 2025 is the premier global hackathon that brings together developers, designers, and innovators from around the world. Over an intense 48-hour period, participants will collaborate remotely to build groundbreaking solutions addressing real-world challenges across various domains including AI, sustainability, healthcare, and education.
            </p>
            <p className="text-primary-200 leading-relaxed">
              Whether you're a seasoned developer, a creative designer, or an ambitious newcomer to the tech scene, HackSphere offers a platform to showcase your talents, learn from peers, connect with industry leaders, and compete for substantial prizes. Join us for a weekend of coding, creativity, and conquering challenges that matter!
            </p>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div className="bg-primary-800/30 backdrop-blur-sm p-8 rounded-xl shadow-md hover:shadow-xl transition-shadow duration-300 text-center border border-accent-500/20">
            <div className="w-16 h-16 mx-auto mb-6 bg-accent-400/20 rounded-full flex items-center justify-center">
              <Code className="w-8 h-8 text-accent-400" />
            </div>
            <h3 className="text-xl font-bold text-white mb-3">Hack</h3>
            <p className="text-primary-200">Build innovative solutions to real-world problems in just 48 hours</p>
          </div>
          
          <div className="bg-primary-800/30 backdrop-blur-sm p-8 rounded-xl shadow-md hover:shadow-xl transition-shadow duration-300 text-center border border-accent-500/20">
            <div className="w-16 h-16 mx-auto mb-6 bg-accent-400/20 rounded-full flex items-center justify-center">
              <Users className="w-8 h-8 text-accent-400" />
            </div>
            <h3 className="text-xl font-bold text-white mb-3">Connect</h3>
            <p className="text-primary-200">Network with like-minded individuals and industry professionals</p>
          </div>
          
          <div className="bg-primary-800/30 backdrop-blur-sm p-8 rounded-xl shadow-md hover:shadow-xl transition-shadow duration-300 text-center border border-accent-500/20">
            <div className="w-16 h-16 mx-auto mb-6 bg-accent-400/20 rounded-full flex items-center justify-center">
              <Coffee className="w-8 h-8 text-accent-400" />
            </div>
            <h3 className="text-xl font-bold text-white mb-3">Learn</h3>
            <p className="text-primary-200">Participate in workshops and gain new skills from experts</p>
          </div>
          
          <div className="bg-primary-800/30 backdrop-blur-sm p-8 rounded-xl shadow-md hover:shadow-xl transition-shadow duration-300 text-center border border-accent-500/20">
            <div className="w-16 h-16 mx-auto mb-6 bg-accent-400/20 rounded-full flex items-center justify-center">
              <Award className="w-8 h-8 text-accent-400" />
            </div>
            <h3 className="text-xl font-bold text-white mb-3">Win</h3>
            <p className="text-primary-200">Compete for $50,000 in prizes across multiple categories</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;