import React from 'react';
import { Facebook, Github, Instagram, Linkedin, Twitter } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-center mb-8">
          <div className="mb-6 md:mb-0">
            <h2 className="text-2xl font-bold">Hack<span className="text-cyan-400">Sphere</span></h2>
            <p className="text-gray-400 mt-2">Code. Create. Conquer.</p>
          </div>
          
          <div className="flex space-x-4">
            <a href="#" className="w-10 h-10 rounded-full bg-gray-800 hover:bg-gray-700 flex items-center justify-center transition-colors duration-300">
              <Twitter className="w-5 h-5" />
            </a>
            <a href="#" className="w-10 h-10 rounded-full bg-gray-800 hover:bg-gray-700 flex items-center justify-center transition-colors duration-300">
              <Facebook className="w-5 h-5" />
            </a>
            <a href="#" className="w-10 h-10 rounded-full bg-gray-800 hover:bg-gray-700 flex items-center justify-center transition-colors duration-300">
              <Instagram className="w-5 h-5" />
            </a>
            <a href="#" className="w-10 h-10 rounded-full bg-gray-800 hover:bg-gray-700 flex items-center justify-center transition-colors duration-300">
              <Linkedin className="w-5 h-5" />
            </a>
            <a href="#" className="w-10 h-10 rounded-full bg-gray-800 hover:bg-gray-700 flex items-center justify-center transition-colors duration-300">
              <Github className="w-5 h-5" />
            </a>
          </div>
        </div>
        
        <div className="flex flex-col md:flex-row justify-center md:justify-between items-center pt-8 border-t border-gray-800">
          <nav className="flex flex-wrap justify-center gap-x-8 gap-y-2 mb-4 md:mb-0">
            <a href="#" className="text-gray-400 hover:text-cyan-400 transition-colors duration-300">Home</a>
            <a href="#about" className="text-gray-400 hover:text-cyan-400 transition-colors duration-300">About</a>
            <a href="#schedule" className="text-gray-400 hover:text-cyan-400 transition-colors duration-300">Schedule</a>
            <a href="#faq" className="text-gray-400 hover:text-cyan-400 transition-colors duration-300">FAQ</a>
            <a href="#partners" className="text-gray-400 hover:text-cyan-400 transition-colors duration-300">Partners</a>
            <a href="#contact" className="text-gray-400 hover:text-cyan-400 transition-colors duration-300">Contact</a>
          </nav>
          
          <p className="text-gray-500 text-sm">
            © 2025 HackSphere. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;